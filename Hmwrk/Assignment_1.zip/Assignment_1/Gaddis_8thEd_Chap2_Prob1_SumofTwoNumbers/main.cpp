/* 
 * File:   main.cpp
 * Author: Jason Emerson
 * Created on September 6, 2016, 12:27 PM
 * Purpose: Calculate the Sum of Two Numbers
 */

#include <iostream>
using namespace std;

int main(int argc, char** argv) {
    unsigned short A=50; //Variable 1=50
    unsigned short B= 100; //Variable 2 = 100
    unsigned short total = A + B; //the sum of two variables = 150 named total
    
    cout<<"The total is "<<total<<"."<<endl;
    
    return 0;
}

